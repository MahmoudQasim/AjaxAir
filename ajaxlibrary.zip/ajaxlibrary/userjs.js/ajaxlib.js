// make ajax request and response.
var xhr = new XMLHttpRequest;
var fd = new FormData();
var AjaxAir = new Function('args','return args');

var $ajaxair = AjaxAir(function(objArgs,Response,loading){
    xhr = new XMLHttpRequest;
    fd = new FormData();
    var x=0;
    var key;
    var DataObj={data:null,loaded:0,total:0};
    for(key in objArgs.data) {
        fd.append(key, objArgs.data[key]);
    }
    xhr.onreadystatechange = function () {
        if(xhr.readyState === 4 && xhr.status === 200){
            DataObj.data = xhr.response;
            AjaxAir(new Response(DataObj));
        }
    };
    xhr.upload.onprogress = function (e) {
        DataObj.total = e.total;
        DataObj.loaded = e.loaded;
        AjaxAir(new loading(DataObj));
    };
    xhr.open(objArgs.method,objArgs.url);
    xhr.send(fd);
});

window.onload = function () {
    document.getElementById('sendBtn').onclick = function () {
        var myname = document.getElementsByTagName('input')[0];
        $ajaxair({
            method:'post',
            url:'./test.php',
            data: {
                ajax:true,
                name:myname.value,
                age:23
            }
        }
        ,function (myData) {
            document.getElementsByTagName('small')[0].innerHTML = myData.data;
        }
        ,function (prog) {
            document.getElementsByTagName('small')[1].innerHTML = prog.total / prog.loaded * 100 + '%';
        });
    }
}