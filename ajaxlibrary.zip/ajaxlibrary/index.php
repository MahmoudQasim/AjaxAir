<!DOCTYPE HTML>
<html>
<head>
	<meta charset='utf-8' />
	<title>MDSDK - ajaxlib</title>
	<link rel='stylesheet' href='userstyle.css/userstyle.css' type='text/css' />
	<script type='text/javascript' src='userjs.js/ajaxlib.js'></script>
</head>
<body class='md'>


	<header>
		<div class='h1'>
			Ajax&nbsp;<b>Air</b>
			<div class='tools'>
				<input type='text' name='' placeholder='Type any thing' />
				<button id='sendBtn'>Send</button>&nbsp;<small data-hidden='false'>Will return response in here.</small>
			    <small data-hidden="false">0</small>
            </div>
		</div>
	</header>
	
	
</body>
</html>