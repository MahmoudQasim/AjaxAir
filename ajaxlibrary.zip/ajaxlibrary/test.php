<?php
if(!empty($_POST['ajax']))
{
    echo 'myname is : ' . $_POST['name'] . ' and myAge is : ' . $_POST['age']. ' years Old ';
}